from django.apps import AppConfig


class BasicApiConfig(AppConfig):
    name = 'basic_api'
