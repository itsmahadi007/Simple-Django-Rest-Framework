# DRFtutorial app for DataFlair
This repository is the code for Django REST Framework tutorial on DataFlair.com
Learn the basics of Django REST Framework and get to know more about RESTful web services. 
# Author: Karan Mittal
# Publisher: DataFlair
